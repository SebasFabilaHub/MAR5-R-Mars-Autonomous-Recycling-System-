import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, 
  Activity, 
  Recycle, 
  Package, 
  BarChart3, 
  Settings,
  Menu,
  X,
  Zap,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const navigationItems = [
  {
    title: "Inicio",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Monitoreo",
    url: createPageUrl("Monitoring"),
    icon: Activity,
  },
  {
    title: "Procesamiento",
    url: createPageUrl("Processing"),
    icon: Recycle,
  },
  {
    title: "Inventario",
    url: createPageUrl("Inventory"),
    icon: Package,
  },
  {
    title: "Estadísticas",
    url: createPageUrl("Statistics"),
    icon: BarChart3,
  },
  {
 