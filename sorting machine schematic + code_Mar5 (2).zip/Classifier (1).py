import RPi.GPIO as GPIO
import time
import cv2
import numpy as np
from smbus2 import SMBus
import VL53L0X
from gpiozero import Servo
import board, busio
from PIL import Image, ImageDraw, ImageFont
from adafruit_ssd1306 import SSD1306_I2C

# ============================
# GPIO CONFIGURATION
# ============================
GPIO.setmode(GPIO.BCM)
LED_PIN = 17
BUZZER_PIN = 27
GPIO.setup([LED_PIN, BUZZER_PIN], GPIO.OUT)

# Servo pins (one for each material)
servo_pins = [4, 5, 6, 12]  # Polymer, Metal, Fabric, Cardboard
servos = []
for pin in servo_pins:
    s = Servo(pin)
    s.mid()
    servos.append(s)

# ============================
# LIDAR SENSOR SETUP
# ============================
tof = VL53L0X.VL53L0X()
tof.open()
tof.start_ranging(VL53L0X.Vl53l0xAccuracyMode.BETTER)

# ============================
# CAMERA SETUP
# ============================
cam = cv2.VideoCapture(0)
cam.set(3, 640)
cam.set(4, 480)

# ============================
# OLED DISPLAY SETUP
# ============================
i2c = busio.I2C(board.SCL, board.SDA)
oled = SSD1306_I2C(128, 64, i2c)
font = ImageFont.load_default()

# ============================
# MATERIAL COUNTERS
# ============================
counter = {
    "polymer": 0,
    "metal": 0,
    "fabric": 0,
    "cardboard": 0
}

# ============================
# OLED UPDATE FUNCTION
# ============================
def update_oled():
    oled.fill(0)
    oled.show()
    image = Image.new("1", (oled.width, oled.height))
    draw = ImageDraw.Draw(image)
    
    draw.text((0, 0), "Material Classifier", font=font, fill=255)
    draw.text((0, 15), f"Polymer:  {counter['polymer']}", font=font, fill=255)
    draw.text((0, 25), f"Metal:    {counter['metal']}", font=font, fill=255)
    draw.text((0, 35), f"Fabric:   {counter['fabric']}", font=font, fill=255)
    draw.text((0, 45), f"Cardboard:{counter['cardboard']}", font=font, fill=255)
    
    oled.image(image)
    oled.show()

update_oled()

# ============================
# MATERIAL CLASSIFICATION (OpenCV)
# ============================
def classify_material(frame):
    # Crop the center region
    h, w, _ = frame.shape
    roi = frame[h//4:3*h//4, w//4:3*w//4]

    # Convert to HSV
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mean_color = np.mean(hsv, axis=(0,1))
    brightness = np.mean(roi)
    texture_var = np.var(cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY))

    H, S, V = mean_color

    # Simple heuristic rules
    if brightness > 160 and texture_var < 500:
        material = "metal"
    elif 10 < H < 30 and S > 60:
        material = "cardboard"
    elif S > 100 and brightness > 100:
        material = "polymer"
    elif texture_var > 1200:
        material = "fabric"
    else:
        material = "unknown"

    return material, (int(H), int(S), int(V)), int(texture_var), int(brightness)

# ============================
# SERVO CONTROL FUNCTION
# ============================
def move_servo(material):
    if material == "polymer":
        servos[0].max()
    elif material == "metal":
        servos[1].max()
    elif material == "fabric":
        servos[2].max()
    elif material == "cardboard":
        servos[3].max()
    else:
        return
    time.sleep(1)
    for s in servos:
        s.mid()

# ============================
# MAIN LOOP
# ============================
try:
    while True:
        distance = tof.get_distance()
        print(f"Distance: {distance} mm")

        if distance < 200:  # Object detected
            GPIO.output(LED_PIN, True)
            GPIO.output(BUZZER_PIN, True)
            time.sleep(0.3)
            GPIO.output(BUZZER_PIN, False)

            ret, frame = cam.read()
            if not ret:
                print("Camera read error")
                continue

            material, hsv_val, texture, bright = classify_material(frame)
            print(f"Material: {material} | HSV: {hsv_val} | Texture: {texture} | Brightness: {bright}")

            if material in counter:
                counter[material] += 1
                update_oled()

            move_servo(material)
            time.sleep(2)

        else:
            GPIO.output(LED_PIN, False)

        time.sleep(0.1)

except KeyboardInterrupt:
    print("Program stopped by user")

finally:
    cam.release()
    tof.stop_ranging()
    GPIO.cleanup()

